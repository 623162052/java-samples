package chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class messageUserList extends HttpServlet {
	private static final long serialVersionUID = -5221513936253154073L;
private static final String CONTENT_TYPE = "text/html; charset=GBK";

  //Initialize global variables
  public void init() throws ServletException {
  }

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    Vector<String> usersVector = (Vector)this.getServletContext().getAttribute("usersVector");
    HttpSession session = request.getSession();
    String userName = (String) session.getAttribute("userName");
    for (int i = 0; i < usersVector.size(); i++) {
      if (String.valueOf(usersVector.get(i)).equals(userName)) {
        out.print("<b>" + String.valueOf(usersVector.get(i)) + "</b><br>");
      }
      else {
        out.print(String.valueOf(usersVector.get(i)) + "<br>");
      }
    }
  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    doGet(request, response);
  }

  //Clean up resources
  public void destroy() {
  }
}