package chat;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class messageSend
    extends HttpServlet {
	private static final long serialVersionUID = -3061935007596925178L;
private static final String CONTENT_TYPE = "text/html; charset=GBK";
  //Initialize global variables
  public void init() throws ServletException {
  }

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession();
    String userName = (String) session.getAttribute("userName");
    out.print("<body onLoad='javascript:frm.msg.focus();'>");
    out.print("<form name='frm' method='post' action='messagemain?userName=" +
              userName + "' target='_parent'>");
    out.print("Message:<input name='msg'>");
    out.print("<input type='submit' value='Submit'>");
    out.print("</form>");
    out.print("</body>");
  }

  public void displayMsgs(PrintWriter out, String userName) {

  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    doGet(request, response);
  }

  //Clean up resources
  public void destroy() {
  }
}