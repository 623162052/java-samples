package chat;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class messageMain extends HttpServlet {
	private static final long serialVersionUID = 1670625528329245986L;
private static final String CONTENT_TYPE = "text/html; charset=GBK";
  //Initialize global variables
  public void init() throws ServletException {
  }

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    String userName = new String(request.getParameter("userName").getBytes("ISO-8859-1"));
    String msg = request.getParameter("msg");
    ServletContext context = this.getServletContext();
    HttpSession session = request.getSession();
    if (userName == null || userName.equals("")) {
      out.print("Pls input your nickname !<br>");
      out.print("<a href='messagelogon'>Back</a>");
      out.close();
    }
    else {
      Vector<String> usersVector = (Vector<String>)this.getServletContext().getAttribute("usersVector");

      if (usersVector == null) {
        usersVector = new Vector<String>();
        usersVector.add(userName);
        session.setAttribute("userName", userName);
        context.setAttribute("usersVector", usersVector);
      }
      else {
        if (!usersVector.contains(userName)) {
          usersVector.add(userName);
          session.setAttribute("userName", userName);
          context.setAttribute("usersVector", usersVector);
        }
      }
    }
    if (msg == null && (StringBuffer) context.getAttribute("msgsBuffer") == null) {
      StringBuffer msgsBuffer = new StringBuffer("");
      context.setAttribute("msgsBuffer", msgsBuffer);
    }
    else if (msg != null) {
      StringBuffer msgsBuffer = (StringBuffer) context.getAttribute(
          "msgsBuffer");
      msgsBuffer.append(userName + ":" + msg + "<br>");
      context.setAttribute("msgsBuffer", msgsBuffer);
    }
    out.print("<frameset rows='80%,*'>");
    out.print("<frame src='messageshow'>");
    out.print("<frame src='messagesend'>");
    out.print("</frameset>");
  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    doGet(request, response);
  }

  //Clean up resources
  public void destroy() {
  }
}